from flask import Flask, render_template, request, redirect, session, url_for
from datetime import datetime, timedelta

app = Flask(__name__)
app.secret_key = 'bd_earning_secret_key'

# Simulate DB
users = {
    'user1': {'password': 'pass1', 'coins': 0, 'vip': False, 'vip_expire': None, 'withdraw_requests': []}
}

# Simple mining cooldown (in seconds)
MINING_COOLDOWN = 60

last_mine_time = {}

@app.route('/')
def home():
    if 'username' in session:
        user = users[session['username']]
        vip_status = user['vip'] and user['vip_expire'] and user['vip_expire'] > datetime.now()
        return render_template('home.html', username=session['username'], coins=user['coins'], vip=vip_status)
    return redirect(url_for('login'))

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username]['password'] == password:
            session['username'] = username
            return redirect(url_for('home'))
        return 'Invalid username or password'
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

@app.route('/mine')
def mine():
    if 'username' not in session:
        return redirect(url_for('login'))
    username = session['username']
    now = datetime.now()
    if username in last_mine_time:
        if now < last_mine_time[username] + timedelta(seconds=MINING_COOLDOWN):
            wait_sec = (last_mine_time[username] + timedelta(seconds=MINING_COOLDOWN) - now).seconds
            return f'Please wait {wait_sec} seconds before mining again.'
    # Add coins depending on VIP
    user = users[username]
    coins_earned = 50 if user['vip'] and user['vip_expire'] and user['vip_expire'] > now else 20
    user['coins'] += coins_earned
    last_mine_time[username] = now
    return redirect(url_for('home'))

@app.route('/withdraw', methods=['GET','POST'])
def withdraw():
    if 'username' not in session:
        return redirect(url_for('login'))
    user = users[session['username']]
    if request.method == 'POST':
        amount = int(request.form['amount'])
        if amount > user['coins']:
            return 'Insufficient coins'
        if amount < 50:
            return 'Minimum withdraw is 50 coins'
        # Simulate withdraw request
        user['coins'] -= amount
        user['withdraw_requests'].append({'amount': amount, 'status': 'Pending'})
        return 'Withdraw request sent. Admin will approve soon.'
    return render_template('withdraw.html', coins=user['coins'])

@app.route('/vip')
def vip():
    if 'username' not in session:
        return redirect(url_for('login'))
    return '''
    <h3>VIP Plans</h3>
    <ul>
    <li>VIP 1: Daily 50 coins, Price: 300৳, Validity: 30 days</li>
    <li>VIP 2: Daily 200 coins, Price: 500৳, Validity: 30 days</li>
    <li>VIP 3: Daily 500 coins, Price: 5000৳, Validity: 30 days</li>
    </ul>
    <p>Contact admin to activate VIP plan.</p>
    <a href="/">Back Home</a>
    '''

if __name__ == '__main__':
    app.run(debug=True)